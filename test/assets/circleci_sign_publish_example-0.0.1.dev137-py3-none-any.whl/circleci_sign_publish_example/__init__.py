"""CircleCI PyPI Publishing Example"""

__version__ = "0.0.1.dev137"


def hello() -> str:
    """Return a greeting from the example."""
    return "hello from the CircleCI PyPI publish example"
