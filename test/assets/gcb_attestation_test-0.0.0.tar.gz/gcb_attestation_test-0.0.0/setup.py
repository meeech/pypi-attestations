from setuptools import setup

setup(
    name="gcb-attestation-test",
    version="0.0.0",
)
